import org.scalatest._
import Codigo.Saludo

abstract class UnitSpec extends FlatSpec with Matchers with OptionValues with Inside with Inspectors

class SaludoTest extends UnitSpec {

  "Saludo" should "devolver hola mundo" in {
    assert(Saludo.saludar() == "hola mundo")
  }

}
