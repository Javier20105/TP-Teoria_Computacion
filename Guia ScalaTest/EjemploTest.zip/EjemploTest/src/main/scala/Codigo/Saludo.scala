package Codigo

object Saludo {

  def saludar():String = {
    "hola mundo"
  }
}
