package org.example.domainmodel.component;

import javax.swing.JButton;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.example.domainmodel.domainmodel.BUTTON;
import org.example.domainmodel.jvmmodel.IInjectable;

@SuppressWarnings("all")
public class Button implements IInjectable<BUTTON> {
  @Override
  public CharSequence getCode(final BUTTON obj, final String prede) {
    StringConcatenation _builder = new StringConcatenation();
    String _name = JButton.class.getName();
    _builder.append(_name);
    _builder.append(" ");
    String _name_1 = obj.getName();
    _builder.append(_name_1);
    _builder.append(" = new ");
    String _name_2 = JButton.class.getName();
    _builder.append(_name_2);
    _builder.append("(\"");
    String _contenido = obj.getContenido();
    _builder.append(_contenido);
    _builder.append("\");");
    _builder.newLineIfNotEmpty();
    _builder.append(prede);
    _builder.append(".add(");
    String _name_3 = obj.getName();
    _builder.append(_name_3);
    _builder.append(");");
    _builder.newLineIfNotEmpty();
    _builder.append("\t");
    _builder.newLine();
    return _builder;
  }
}
