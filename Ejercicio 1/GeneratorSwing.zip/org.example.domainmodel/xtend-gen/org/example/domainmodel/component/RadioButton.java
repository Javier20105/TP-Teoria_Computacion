package org.example.domainmodel.component;

import javax.swing.JRadioButton;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.example.domainmodel.domainmodel.RADIOBUTTON;
import org.example.domainmodel.jvmmodel.IInjectable;

@SuppressWarnings("all")
public class RadioButton implements IInjectable<RADIOBUTTON> {
  @Override
  public CharSequence getCode(final RADIOBUTTON obj, final String prede) {
    StringConcatenation _builder = new StringConcatenation();
    String _name = JRadioButton.class.getName();
    _builder.append(_name);
    _builder.append(" ");
    String _name_1 = obj.getName();
    _builder.append(_name_1);
    _builder.append(" = new ");
    String _name_2 = JRadioButton.class.getName();
    _builder.append(_name_2);
    _builder.append("(\"");
    String _contenido = obj.getContenido();
    _builder.append(_contenido);
    _builder.append("\");");
    _builder.newLineIfNotEmpty();
    String _name_3 = obj.getName();
    _builder.append(_name_3);
    _builder.append(".setSelected(");
    String _state = obj.getSelect().getState();
    _builder.append(_state);
    _builder.append(");");
    _builder.newLineIfNotEmpty();
    _builder.append(prede);
    _builder.append(".add(");
    String _name_4 = obj.getName();
    _builder.append(_name_4);
    _builder.append(");");
    _builder.newLineIfNotEmpty();
    _builder.newLine();
    return _builder;
  }
}
