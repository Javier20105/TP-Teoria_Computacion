package org.example.domainmodel.component;

import org.eclipse.emf.common.util.EList;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.example.domainmodel.domainmodel.MENUFRAME;
import org.example.domainmodel.jvmmodel.IInjectable;

@SuppressWarnings("all")
public class MenuFrame implements IInjectable<MENUFRAME> {
  @Override
  public CharSequence getCode(final MENUFRAME obj, final String prede) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("this.setName(\"MenuFrame\");");
    _builder.newLine();
    _builder.append("this.setVisible(true);");
    _builder.newLine();
    _builder.append("this.setBounds(200, 100, 900, 700);");
    _builder.newLine();
    _builder.append("this.setLayout(null);");
    _builder.newLine();
    _builder.append("this.menuBar = new JMenuBar();");
    _builder.newLine();
    _builder.append("this.setJMenuBar(menuBar);");
    _builder.newLine();
    _builder.append("this.menuFrames = new JMenu(\"Frames\");");
    _builder.newLine();
    _builder.append("this.menuBar.add(menuFrames);");
    _builder.newLine();
    _builder.newLine();
    {
      EList<String> _compMenuFrame = obj.getCompMenuFrame();
      for(final String i : _compMenuFrame) {
        _builder.append("this.item");
        _builder.append(i);
        _builder.append(" =new JMenuItem(\"");
        _builder.append(i);
        _builder.append("\");");
        _builder.newLineIfNotEmpty();
        _builder.append("this.menuFrames.add(item");
        _builder.append(i);
        _builder.append(");");
        _builder.newLineIfNotEmpty();
        _builder.append("this.item");
        _builder.append(i);
        _builder.append(".addActionListener(this);");
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.newLine();
    return _builder;
  }
}
