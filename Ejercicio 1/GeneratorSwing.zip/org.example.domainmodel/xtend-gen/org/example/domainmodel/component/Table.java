package org.example.domainmodel.component;

import javax.swing.JScrollPane;
import javax.swing.JTable;
import org.eclipse.emf.common.util.EList;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.example.domainmodel.domainmodel.ROW;
import org.example.domainmodel.domainmodel.TABLE;
import org.example.domainmodel.jvmmodel.IInjectable;

@SuppressWarnings("all")
public class Table implements IInjectable<TABLE> {
  @Override
  public CharSequence getCode(final TABLE obj, final String prede) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("String[] col");
    String _name = obj.getName();
    _builder.append(_name);
    _builder.append(" = new String[] { ");
    {
      EList<String> _compHead = obj.getHead().getCompHead();
      for(final String j : _compHead) {
        _builder.append(" \"");
        _builder.append(j);
        _builder.append("\", ");
      }
    }
    _builder.append("};");
    _builder.newLineIfNotEmpty();
    _builder.append("String[][] data");
    String _name_1 = obj.getName();
    _builder.append(_name_1);
    _builder.append(" = new String[][] {");
    _builder.newLineIfNotEmpty();
    {
      EList<ROW> _compData = obj.getCompData();
      for(final ROW i : _compData) {
        _builder.append("{");
        {
          EList<String> _compData_1 = i.getCompData();
          for(final String k : _compData_1) {
            _builder.append(" \"");
            _builder.append(k);
            _builder.append("\",");
          }
        }
        _builder.append("},");
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.append("};");
    _builder.newLine();
    _builder.newLine();
    String _name_2 = JTable.class.getName();
    _builder.append(_name_2);
    _builder.append(" ");
    String _name_3 = obj.getName();
    _builder.append(_name_3);
    _builder.append(" = new ");
    String _name_4 = JTable.class.getName();
    _builder.append(_name_4);
    _builder.append("(data");
    String _name_5 = obj.getName();
    _builder.append(_name_5);
    _builder.append(", col");
    String _name_6 = obj.getName();
    _builder.append(_name_6);
    _builder.append(");");
    _builder.newLineIfNotEmpty();
    _builder.append(prede);
    _builder.append(".add(new ");
    String _name_7 = JScrollPane.class.getName();
    _builder.append(_name_7);
    _builder.append("(");
    String _name_8 = obj.getName();
    _builder.append(_name_8);
    _builder.append("));");
    _builder.newLineIfNotEmpty();
    _builder.newLine();
    return _builder;
  }
}
