package org.example.domainmodel.component;

import javax.swing.JTextField;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.example.domainmodel.domainmodel.TEXTFIELD;
import org.example.domainmodel.jvmmodel.IInjectable;

@SuppressWarnings("all")
public class TextField implements IInjectable<TEXTFIELD> {
  @Override
  public CharSequence getCode(final TEXTFIELD obj, final String prede) {
    StringConcatenation _builder = new StringConcatenation();
    String _name = JTextField.class.getName();
    _builder.append(_name);
    _builder.append(" ");
    String _name_1 = obj.getName();
    _builder.append(_name_1);
    _builder.append(" = new ");
    String _name_2 = JTextField.class.getName();
    _builder.append(_name_2);
    _builder.append("(\"");
    String _contenido = obj.getContenido();
    _builder.append(_contenido);
    _builder.append("\");");
    _builder.newLineIfNotEmpty();
    _builder.append(prede);
    _builder.append(".add(");
    String _name_3 = obj.getName();
    _builder.append(_name_3);
    _builder.append(");");
    _builder.newLineIfNotEmpty();
    _builder.newLine();
    return _builder;
  }
}
