package org.example.domainmodel.component;

import javax.swing.JTabbedPane;
import org.eclipse.emf.common.util.EList;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.example.domainmodel.domainmodel.PANEL;
import org.example.domainmodel.domainmodel.TABBEDPANE;
import org.example.domainmodel.jvmmodel.IInjectable;

@SuppressWarnings("all")
public class TabbedPane implements IInjectable<TABBEDPANE> {
  @Override
  public CharSequence getCode(final TABBEDPANE obj, final String prede) {
    StringConcatenation _builder = new StringConcatenation();
    String _name = JTabbedPane.class.getName();
    _builder.append(_name);
    _builder.append(" ");
    String _name_1 = obj.getName();
    _builder.append(_name_1);
    _builder.append(" = new ");
    String _name_2 = JTabbedPane.class.getName();
    _builder.append(_name_2);
    _builder.append("();");
    _builder.newLineIfNotEmpty();
    {
      EList<PANEL> _compTabbed = obj.getCompTabbed();
      for(final PANEL k : _compTabbed) {
        String _name_3 = obj.getName();
        _builder.append(_name_3);
        _builder.append(".addTab(\"");
        String _tab = k.getTab();
        _builder.append(_tab);
        _builder.append("\", ");
        String _name_4 = k.getName();
        _builder.append(_name_4);
        _builder.append(");");
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.append(prede);
    _builder.append(".add(");
    String _name_5 = obj.getName();
    _builder.append(_name_5);
    _builder.append(");");
    _builder.newLineIfNotEmpty();
    _builder.newLine();
    return _builder;
  }
}
