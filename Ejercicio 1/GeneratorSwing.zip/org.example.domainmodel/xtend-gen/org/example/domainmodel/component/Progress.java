package org.example.domainmodel.component;

import javax.swing.JProgressBar;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.example.domainmodel.domainmodel.PROGRESS;
import org.example.domainmodel.jvmmodel.IInjectable;

@SuppressWarnings("all")
public class Progress implements IInjectable<PROGRESS> {
  @Override
  public CharSequence getCode(final PROGRESS obj, final String prede) {
    StringConcatenation _builder = new StringConcatenation();
    String _name = JProgressBar.class.getName();
    _builder.append(_name);
    _builder.append(" ");
    String _name_1 = obj.getName();
    _builder.append(_name_1);
    _builder.append(" = new ");
    String _name_2 = JProgressBar.class.getName();
    _builder.append(_name_2);
    _builder.append("(");
    int _min = obj.getMin();
    _builder.append(_min);
    _builder.append(", ");
    int _max = obj.getMax();
    _builder.append(_max);
    _builder.append(");");
    _builder.newLineIfNotEmpty();
    String _name_3 = obj.getName();
    _builder.append(_name_3);
    _builder.append(".setValue(");
    int _progres = obj.getProgres();
    _builder.append(_progres);
    _builder.append(");");
    _builder.newLineIfNotEmpty();
    _builder.append(prede);
    _builder.append(".add(");
    String _name_4 = obj.getName();
    _builder.append(_name_4);
    _builder.append(");");
    _builder.newLineIfNotEmpty();
    _builder.newLine();
    return _builder;
  }
}
