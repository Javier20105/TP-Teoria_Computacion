package org.example.domainmodel.jvmmodel;

import org.eclipse.xtend2.lib.StringConcatenation;
import org.example.domainmodel.jvmmodel.IInject;

@SuppressWarnings("all")
public class Action implements IInject<String> {
  @Override
  public CharSequence getCode(final String obj, final String prede) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("if (e.getSource()== item");
    _builder.append(obj);
    _builder.append(") {");
    _builder.newLineIfNotEmpty();
    _builder.append("\t");
    _builder.append(obj, "\t");
    _builder.append(" ");
    _builder.append(obj, "\t");
    _builder.append(" = new ");
    _builder.append(obj, "\t");
    _builder.append("(\"hola\");");
    _builder.newLineIfNotEmpty();
    _builder.append("\t");
    _builder.append(obj, "\t");
    _builder.append("._init();");
    _builder.newLineIfNotEmpty();
    _builder.append("\t");
    _builder.append("}");
    _builder.newLine();
    _builder.append("\t");
    _builder.newLine();
    return _builder;
  }
}
