package org.example.domainmodel.jvmmodel;

import javax.swing.JComboBox;
import org.eclipse.emf.common.util.EList;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.example.domainmodel.domainmodel.COMBOBOX;
import org.example.domainmodel.jvmmodel.IInject;

@SuppressWarnings("all")
public class ComboBox implements IInject<COMBOBOX> {
  @Override
  public CharSequence getCode(final COMBOBOX obj, final String prede) {
    StringConcatenation _builder = new StringConcatenation();
    String _name = JComboBox.class.getName();
    _builder.append(_name);
    _builder.append(" ");
    String _name_1 = obj.getName();
    _builder.append(_name_1);
    _builder.append(" = new ");
    String _name_2 = JComboBox.class.getName();
    _builder.append(_name_2);
    _builder.append("();");
    _builder.newLineIfNotEmpty();
    {
      EList<String> _compCombo = obj.getCompCombo();
      for(final String k : _compCombo) {
        String _name_3 = obj.getName();
        _builder.append(_name_3);
        _builder.append(".addItem(\"");
        _builder.append(k);
        _builder.append("\");");
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.append(prede);
    _builder.append(".add(");
    String _name_4 = obj.getName();
    _builder.append(_name_4);
    _builder.append(");");
    _builder.newLineIfNotEmpty();
    _builder.newLine();
    return _builder;
  }
}
