package org.example.domainmodel.jvmmodel;

@SuppressWarnings("all")
public interface IInject<T extends Object> {
  public abstract CharSequence getCode(final T obj, final String prede);
}
