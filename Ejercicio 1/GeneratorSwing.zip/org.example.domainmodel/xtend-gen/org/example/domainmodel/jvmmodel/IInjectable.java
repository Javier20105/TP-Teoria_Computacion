package org.example.domainmodel.jvmmodel;

@SuppressWarnings("all")
public interface IInjectable<T extends Object> {
  public abstract CharSequence getCode(final T obj, final String prede);
}
