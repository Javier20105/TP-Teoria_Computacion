package org.example.domainmodel.jvmmodel;

import org.example.domainmodel.jvmmodel.IInject;

@SuppressWarnings("all")
public class Injector<T extends Object> {
  public <T extends Object> CharSequence injectCode(final T element, final IInject<T> type, final String prede) {
    return type.getCode(element, prede);
  }
}
