package org.example.domainmodel.jvmmodel;

import org.example.domainmodel.jvmmodel.IInjectable;

@SuppressWarnings("all")
public class Injector<T extends Object> {
  public <T extends Object> CharSequence injectCode(final T element, final IInjectable<T> type, final String prede) {
    return type.getCode(element, prede);
  }
}
