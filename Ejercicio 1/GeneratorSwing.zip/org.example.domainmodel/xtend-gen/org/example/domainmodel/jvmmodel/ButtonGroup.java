package org.example.domainmodel.jvmmodel;

import org.eclipse.emf.common.util.EList;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.example.domainmodel.domainmodel.BUTTONGROUP;
import org.example.domainmodel.domainmodel.RADIOBUTTON;
import org.example.domainmodel.jvmmodel.IInject;

@SuppressWarnings("all")
public class ButtonGroup implements IInject<BUTTONGROUP> {
  @Override
  public CharSequence getCode(final BUTTONGROUP obj, final String prede) {
    StringConcatenation _builder = new StringConcatenation();
    String _name = javax.swing.ButtonGroup.class.getName();
    _builder.append(_name);
    _builder.append(" ");
    String _name_1 = obj.getName();
    _builder.append(_name_1);
    _builder.append(" = new ");
    String _name_2 = javax.swing.ButtonGroup.class.getName();
    _builder.append(_name_2);
    _builder.append("();");
    _builder.newLineIfNotEmpty();
    {
      EList<RADIOBUTTON> _compGroup = obj.getCompGroup();
      for(final RADIOBUTTON k : _compGroup) {
        String _name_3 = obj.getName();
        _builder.append(_name_3);
        _builder.append(".add(");
        String _name_4 = k.getName();
        _builder.append(_name_4);
        _builder.append(");");
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.newLine();
    return _builder;
  }
}
