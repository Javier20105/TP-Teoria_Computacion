package org.example.domainmodel.jvmmodel;

import java.awt.Color;
import java.awt.GridLayout;
import javax.swing.JPanel;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.example.domainmodel.domainmodel.BOOLEAN;
import org.example.domainmodel.domainmodel.PANEL;
import org.example.domainmodel.jvmmodel.IInject;

@SuppressWarnings("all")
public class Panel implements IInject<PANEL> {
  @Override
  public CharSequence getCode(final PANEL obj, final String prede) {
    StringConcatenation _builder = new StringConcatenation();
    String _name = JPanel.class.getName();
    _builder.append(_name);
    _builder.append(" ");
    String _name_1 = obj.getName();
    _builder.append(_name_1);
    _builder.append(" = new ");
    String _name_2 = JPanel.class.getName();
    _builder.append(_name_2);
    _builder.append("();");
    _builder.newLineIfNotEmpty();
    String _name_3 = obj.getName();
    _builder.append(_name_3);
    _builder.append(".setBackground(");
    String _name_4 = Color.class.getName();
    _builder.append(_name_4);
    _builder.append(".");
    String _color = obj.getColor().getColor();
    _builder.append(_color);
    _builder.append(");");
    _builder.newLineIfNotEmpty();
    {
      BOOLEAN _tabbed = obj.getTabbed();
      boolean _tripleEquals = (_tabbed == null);
      if (_tripleEquals) {
        _builder.append(prede);
        _builder.append(".add(");
        String _name_5 = obj.getName();
        _builder.append(_name_5);
        _builder.append(");");
        _builder.newLineIfNotEmpty();
      }
    }
    String _name_6 = obj.getName();
    _builder.append(_name_6);
    _builder.append(".setLayout(new ");
    String _name_7 = GridLayout.class.getName();
    _builder.append(_name_7);
    _builder.append("(1, 1));\t");
    _builder.newLineIfNotEmpty();
    _builder.append("\t\t\t\t\t\t\t\t\t");
    _builder.newLine();
    return _builder;
  }
}
