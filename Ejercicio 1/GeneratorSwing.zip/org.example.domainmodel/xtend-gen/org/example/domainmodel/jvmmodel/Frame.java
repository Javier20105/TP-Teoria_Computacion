package org.example.domainmodel.jvmmodel;

import java.awt.GridLayout;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.example.domainmodel.domainmodel.FRAME;
import org.example.domainmodel.jvmmodel.IInject;

@SuppressWarnings("all")
public class Frame implements IInject<FRAME> {
  @Override
  public CharSequence getCode(final FRAME obj, final String prede) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("this.setName(name);");
    _builder.newLine();
    _builder.append("this.setVisible(true);");
    _builder.newLine();
    _builder.append("this.setBounds(200, 100, 900, 700);");
    _builder.newLine();
    _builder.append("this.container = new JPanel();");
    _builder.newLine();
    _builder.append("this.setContentPane(this.container);");
    _builder.newLine();
    _builder.append("this.container.setLayout(new ");
    String _name = GridLayout.class.getName();
    _builder.append(_name);
    _builder.append("(1, 1));\t");
    _builder.newLineIfNotEmpty();
    return _builder;
  }
}
