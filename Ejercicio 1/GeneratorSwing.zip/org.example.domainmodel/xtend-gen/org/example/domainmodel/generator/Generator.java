package org.example.domainmodel.generator;

import java.util.List;
import org.eclipse.emf.common.util.EList;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.example.domainmodel.component.Action;
import org.example.domainmodel.component.Button;
import org.example.domainmodel.component.ButtonGroup;
import org.example.domainmodel.component.CheckBox;
import org.example.domainmodel.component.ComboBox;
import org.example.domainmodel.component.Label;
import org.example.domainmodel.component.Panel;
import org.example.domainmodel.component.Password;
import org.example.domainmodel.component.Progress;
import org.example.domainmodel.component.RadioButton;
import org.example.domainmodel.component.TabbedPane;
import org.example.domainmodel.component.Table;
import org.example.domainmodel.component.TextField;
import org.example.domainmodel.domainmodel.BUTTON;
import org.example.domainmodel.domainmodel.BUTTONGROUP;
import org.example.domainmodel.domainmodel.CHECKBOX;
import org.example.domainmodel.domainmodel.COMBOBOX;
import org.example.domainmodel.domainmodel.COMP;
import org.example.domainmodel.domainmodel.LABEL;
import org.example.domainmodel.domainmodel.PANEL;
import org.example.domainmodel.domainmodel.PASSWORD;
import org.example.domainmodel.domainmodel.PROGRESS;
import org.example.domainmodel.domainmodel.RADIOBUTTON;
import org.example.domainmodel.domainmodel.TABBEDPANE;
import org.example.domainmodel.domainmodel.TABLE;
import org.example.domainmodel.domainmodel.TEXTFIELD;
import org.example.domainmodel.jvmmodel.Injector;

@SuppressWarnings("all")
public class Generator<T extends Object> {
  private Injector<Object> injector = new Injector<Object>();
  
  public <T extends Object> StringBuffer generateComponent(final List<T> element, final String prede) {
    StringBuffer members = new StringBuffer();
    String option = "";
    for (final T comp : element) {
      boolean _matched = false;
      if (comp instanceof PANEL) {
        _matched=true;
        String _option = option;
        StringConcatenation _builder = new StringConcatenation();
        Panel _panel = new Panel();
        CharSequence _injectCode = this.injector.<PANEL>injectCode(((PANEL)comp), _panel, prede);
        _builder.append(_injectCode);
        option = (_option + _builder);
        String _option_1 = option;
        EList<COMP> _compPanel = ((PANEL)comp).getCompPanel();
        StringBuffer _generateComponent = this.<T>generateComponent(((List<T>) _compPanel), ((PANEL)comp).getName());
        option = (_option_1 + _generateComponent);
      }
      if (!_matched) {
        if (comp instanceof BUTTONGROUP) {
          _matched=true;
          String _option = option;
          EList<RADIOBUTTON> _compGroup = ((BUTTONGROUP)comp).getCompGroup();
          StringBuffer _generateComponent = this.<T>generateComponent(((List<T>) _compGroup), prede);
          option = (_option + _generateComponent);
          String _option_1 = option;
          StringConcatenation _builder = new StringConcatenation();
          ButtonGroup _buttonGroup = new ButtonGroup();
          CharSequence _injectCode = this.injector.<BUTTONGROUP>injectCode(((BUTTONGROUP)comp), _buttonGroup, prede);
          _builder.append(_injectCode);
          option = (_option_1 + _builder);
        }
      }
      if (!_matched) {
        if (comp instanceof TABBEDPANE) {
          _matched=true;
          String _option = option;
          EList<PANEL> _compTabbed = ((TABBEDPANE)comp).getCompTabbed();
          StringBuffer _generateComponent = this.<T>generateComponent(((List<T>) _compTabbed), ((TABBEDPANE)comp).getName());
          option = (_option + _generateComponent);
          String _option_1 = option;
          StringConcatenation _builder = new StringConcatenation();
          TabbedPane _tabbedPane = new TabbedPane();
          CharSequence _injectCode = this.injector.<TABBEDPANE>injectCode(((TABBEDPANE)comp), _tabbedPane, prede);
          _builder.append(_injectCode);
          option = (_option_1 + _builder);
        }
      }
      if (!_matched) {
        if (comp instanceof LABEL) {
          _matched=true;
          String _option = option;
          StringConcatenation _builder = new StringConcatenation();
          Label _label = new Label();
          CharSequence _injectCode = this.injector.<LABEL>injectCode(((LABEL)comp), _label, prede);
          _builder.append(_injectCode);
          option = (_option + _builder);
        }
      }
      if (!_matched) {
        if (comp instanceof BUTTON) {
          _matched=true;
          String _option = option;
          StringConcatenation _builder = new StringConcatenation();
          Button _button = new Button();
          CharSequence _injectCode = this.injector.<BUTTON>injectCode(((BUTTON)comp), _button, prede);
          _builder.append(_injectCode);
          option = (_option + _builder);
        }
      }
      if (!_matched) {
        if (comp instanceof RADIOBUTTON) {
          _matched=true;
          String _option = option;
          StringConcatenation _builder = new StringConcatenation();
          RadioButton _radioButton = new RadioButton();
          CharSequence _injectCode = this.injector.<RADIOBUTTON>injectCode(((RADIOBUTTON)comp), _radioButton, prede);
          _builder.append(_injectCode);
          option = (_option + _builder);
        }
      }
      if (!_matched) {
        if (comp instanceof TEXTFIELD) {
          _matched=true;
          String _option = option;
          StringConcatenation _builder = new StringConcatenation();
          TextField _textField = new TextField();
          CharSequence _injectCode = this.injector.<TEXTFIELD>injectCode(((TEXTFIELD)comp), _textField, prede);
          _builder.append(_injectCode);
          option = (_option + _builder);
        }
      }
      if (!_matched) {
        if (comp instanceof CHECKBOX) {
          _matched=true;
          String _option = option;
          StringConcatenation _builder = new StringConcatenation();
          CheckBox _checkBox = new CheckBox();
          CharSequence _injectCode = this.injector.<CHECKBOX>injectCode(((CHECKBOX)comp), _checkBox, prede);
          _builder.append(_injectCode);
          option = (_option + _builder);
        }
      }
      if (!_matched) {
        if (comp instanceof COMBOBOX) {
          _matched=true;
          String _option = option;
          StringConcatenation _builder = new StringConcatenation();
          ComboBox _comboBox = new ComboBox();
          CharSequence _injectCode = this.injector.<COMBOBOX>injectCode(((COMBOBOX)comp), _comboBox, prede);
          _builder.append(_injectCode);
          option = (_option + _builder);
        }
      }
      if (!_matched) {
        if (comp instanceof String) {
          _matched=true;
          String _option = option;
          StringConcatenation _builder = new StringConcatenation();
          Action _action = new Action();
          CharSequence _injectCode = this.injector.<String>injectCode(((String)comp), _action, prede);
          _builder.append(_injectCode);
          option = (_option + _builder);
        }
      }
      if (!_matched) {
        if (comp instanceof TABLE) {
          _matched=true;
          String _option = option;
          StringConcatenation _builder = new StringConcatenation();
          Table _table = new Table();
          CharSequence _injectCode = this.injector.<TABLE>injectCode(((TABLE)comp), _table, prede);
          _builder.append(_injectCode);
          option = (_option + _builder);
        }
      }
      if (!_matched) {
        if (comp instanceof PROGRESS) {
          _matched=true;
          String _option = option;
          StringConcatenation _builder = new StringConcatenation();
          Progress _progress = new Progress();
          CharSequence _injectCode = this.injector.<PROGRESS>injectCode(((PROGRESS)comp), _progress, prede);
          _builder.append(_injectCode);
          option = (_option + _builder);
        }
      }
      if (!_matched) {
        if (comp instanceof PASSWORD) {
          _matched=true;
          String _option = option;
          StringConcatenation _builder = new StringConcatenation();
          Password _password = new Password();
          CharSequence _injectCode = this.injector.<PASSWORD>injectCode(((PASSWORD)comp), _password, prede);
          _builder.append(_injectCode);
          option = (_option + _builder);
        }
      }
    }
    members.append(option);
    return members;
  }
}
