package org.example.domainmodel.generator;

import java.util.List;
import org.eclipse.emf.common.util.EList;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.example.domainmodel.domainmodel.BUTTON;
import org.example.domainmodel.domainmodel.BUTTONGROUP;
import org.example.domainmodel.domainmodel.CHECKBOX;
import org.example.domainmodel.domainmodel.COMBOBOX;
import org.example.domainmodel.domainmodel.COMP;
import org.example.domainmodel.domainmodel.LABEL;
import org.example.domainmodel.domainmodel.PANEL;
import org.example.domainmodel.domainmodel.RADIOBUTTON;
import org.example.domainmodel.domainmodel.TABBEDPANE;
import org.example.domainmodel.domainmodel.TEXTFIELD;
import org.example.domainmodel.jvmmodel.Action;
import org.example.domainmodel.jvmmodel.Button;
import org.example.domainmodel.jvmmodel.ButtonGroup;
import org.example.domainmodel.jvmmodel.CheckBox;
import org.example.domainmodel.jvmmodel.ComboBox;
import org.example.domainmodel.jvmmodel.Injector;
import org.example.domainmodel.jvmmodel.Label;
import org.example.domainmodel.jvmmodel.Panel;
import org.example.domainmodel.jvmmodel.RadioButton;
import org.example.domainmodel.jvmmodel.TabbedPane;
import org.example.domainmodel.jvmmodel.TextField;

@SuppressWarnings("all")
public class Generator<T extends Object> {
  public <T extends Object> StringBuffer generateComponent(final List<T> element, final String prede) {
    StringBuffer members = new StringBuffer();
    Injector<Object> injector = new Injector<Object>();
    for (final T comp : element) {
      boolean _matched = false;
      if (comp instanceof PANEL) {
        _matched=true;
        StringConcatenation _builder = new StringConcatenation();
        Panel _panel = new Panel();
        CharSequence _injectCode = injector.<PANEL>injectCode(((PANEL)comp), _panel, prede);
        _builder.append(_injectCode);
        members.append(_builder);
        EList<COMP> _compPanel = ((PANEL)comp).getCompPanel();
        members.append(this.<T>generateComponent(((List<T>) _compPanel), ((PANEL)comp).getName()));
      }
      if (!_matched) {
        if (comp instanceof BUTTONGROUP) {
          _matched=true;
          EList<RADIOBUTTON> _compGroup = ((BUTTONGROUP)comp).getCompGroup();
          members.append(this.<T>generateComponent(((List<T>) _compGroup), prede));
          StringConcatenation _builder = new StringConcatenation();
          ButtonGroup _buttonGroup = new ButtonGroup();
          CharSequence _injectCode = injector.<BUTTONGROUP>injectCode(((BUTTONGROUP)comp), _buttonGroup, prede);
          _builder.append(_injectCode);
          members.append(_builder);
        }
      }
      if (!_matched) {
        if (comp instanceof TABBEDPANE) {
          _matched=true;
          EList<PANEL> _compTabbed = ((TABBEDPANE)comp).getCompTabbed();
          members.append(this.<T>generateComponent(((List<T>) _compTabbed), ((TABBEDPANE)comp).getName()));
          StringConcatenation _builder = new StringConcatenation();
          TabbedPane _tabbedPane = new TabbedPane();
          CharSequence _injectCode = injector.<TABBEDPANE>injectCode(((TABBEDPANE)comp), _tabbedPane, prede);
          _builder.append(_injectCode);
          members.append(_builder);
        }
      }
      if (!_matched) {
        if (comp instanceof LABEL) {
          _matched=true;
          StringConcatenation _builder = new StringConcatenation();
          Label _label = new Label();
          CharSequence _injectCode = injector.<LABEL>injectCode(((LABEL)comp), _label, prede);
          _builder.append(_injectCode);
          members.append(_builder);
        }
      }
      if (!_matched) {
        if (comp instanceof BUTTON) {
          _matched=true;
          StringConcatenation _builder = new StringConcatenation();
          Button _button = new Button();
          CharSequence _injectCode = injector.<BUTTON>injectCode(((BUTTON)comp), _button, prede);
          _builder.append(_injectCode);
          members.append(_builder);
        }
      }
      if (!_matched) {
        if (comp instanceof RADIOBUTTON) {
          _matched=true;
          StringConcatenation _builder = new StringConcatenation();
          RadioButton _radioButton = new RadioButton();
          CharSequence _injectCode = injector.<RADIOBUTTON>injectCode(((RADIOBUTTON)comp), _radioButton, prede);
          _builder.append(_injectCode);
          members.append(_builder);
        }
      }
      if (!_matched) {
        if (comp instanceof TEXTFIELD) {
          _matched=true;
          StringConcatenation _builder = new StringConcatenation();
          TextField _textField = new TextField();
          CharSequence _injectCode = injector.<TEXTFIELD>injectCode(((TEXTFIELD)comp), _textField, prede);
          _builder.append(_injectCode);
          members.append(_builder);
        }
      }
      if (!_matched) {
        if (comp instanceof CHECKBOX) {
          _matched=true;
          StringConcatenation _builder = new StringConcatenation();
          CheckBox _checkBox = new CheckBox();
          CharSequence _injectCode = injector.<CHECKBOX>injectCode(((CHECKBOX)comp), _checkBox, prede);
          _builder.append(_injectCode);
          members.append(_builder);
        }
      }
      if (!_matched) {
        if (comp instanceof COMBOBOX) {
          _matched=true;
          StringConcatenation _builder = new StringConcatenation();
          ComboBox _comboBox = new ComboBox();
          CharSequence _injectCode = injector.<COMBOBOX>injectCode(((COMBOBOX)comp), _comboBox, prede);
          _builder.append(_injectCode);
          members.append(_builder);
        }
      }
      if (!_matched) {
        if (comp instanceof String) {
          _matched=true;
          StringConcatenation _builder = new StringConcatenation();
          Action _action = new Action();
          CharSequence _injectCode = injector.<String>injectCode(((String)comp), _action, prede);
          _builder.append(_injectCode);
          members.append(_builder);
        }
      }
    }
    return members;
  }
}
