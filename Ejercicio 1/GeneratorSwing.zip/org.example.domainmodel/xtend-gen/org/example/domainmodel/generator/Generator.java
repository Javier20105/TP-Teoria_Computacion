package org.example.domainmodel.generator;

import java.awt.Color;
import java.awt.GridLayout;
import java.util.List;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;
import org.eclipse.emf.common.util.EList;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.example.domainmodel.domainmodel.BOOLEAN;
import org.example.domainmodel.domainmodel.BUTTON;
import org.example.domainmodel.domainmodel.BUTTONGROUP;
import org.example.domainmodel.domainmodel.CHECKBOX;
import org.example.domainmodel.domainmodel.COMBOBOX;
import org.example.domainmodel.domainmodel.COMP;
import org.example.domainmodel.domainmodel.LABEL;
import org.example.domainmodel.domainmodel.PANEL;
import org.example.domainmodel.domainmodel.RADIOBUTTON;
import org.example.domainmodel.domainmodel.TABBEDPANE;
import org.example.domainmodel.domainmodel.TEXTFIELD;

@SuppressWarnings("all")
public class Generator<T extends Object> {
  public <T extends Object> StringBuffer generateComponent(final List<T> element, final String prede) {
    StringBuffer members = new StringBuffer();
    for (final T comp : element) {
      boolean _matched = false;
      if (comp instanceof PANEL) {
        _matched=true;
        StringConcatenation _builder = new StringConcatenation();
        CharSequence _injectCode = this.<T>injectCode(((T)comp), prede);
        _builder.append(_injectCode);
        members.append(_builder);
        EList<COMP> _compPanel = ((PANEL)comp).getCompPanel();
        members.append(this.<T>generateComponent(((List<T>) _compPanel), ((PANEL)comp).getName()));
      }
      if (!_matched) {
        if (comp instanceof BUTTONGROUP) {
          _matched=true;
          EList<RADIOBUTTON> _compGroup = ((BUTTONGROUP)comp).getCompGroup();
          members.append(this.<T>generateComponent(((List<T>) _compGroup), prede));
          StringConcatenation _builder = new StringConcatenation();
          CharSequence _injectCode = this.<T>injectCode(((T)comp), prede);
          _builder.append(_injectCode);
          members.append(_builder);
        }
      }
      if (!_matched) {
        if (comp instanceof TABBEDPANE) {
          _matched=true;
          EList<PANEL> _compTabbed = ((TABBEDPANE)comp).getCompTabbed();
          members.append(this.<T>generateComponent(((List<T>) _compTabbed), ((TABBEDPANE)comp).getName()));
          StringConcatenation _builder = new StringConcatenation();
          CharSequence _injectCode = this.<T>injectCode(((T)comp), prede);
          _builder.append(_injectCode);
          members.append(_builder);
        }
      }
      if (!_matched) {
        if (comp instanceof LABEL) {
          _matched=true;
        }
        if (!_matched) {
          if (comp instanceof BUTTON) {
            _matched=true;
          }
        }
        if (!_matched) {
          if (comp instanceof RADIOBUTTON) {
            _matched=true;
          }
        }
        if (!_matched) {
          if (comp instanceof TEXTFIELD) {
            _matched=true;
          }
        }
        if (!_matched) {
          if (comp instanceof CHECKBOX) {
            _matched=true;
          }
        }
        if (!_matched) {
          if (comp instanceof COMBOBOX) {
            _matched=true;
          }
        }
        if (_matched) {
          StringConcatenation _builder = new StringConcatenation();
          CharSequence _injectCode = this.<T>injectCode(((T)comp), prede);
          _builder.append(_injectCode);
          members.append(_builder);
        }
      }
    }
    return members;
  }
  
  /**
   * def <T> StringBuffer generateContainer(List<T> element, String prede){
   * var members = new StringBuffer();
   * for (comp : element){
   * if( comp instanceof RADIOBUTTON){
   * members.append( '''«injectCode(comp, prede)»''')
   * }
   * else if( comp instanceof PANEL){
   * members.append('''«injectCode(comp, comp.name)»''')
   * members.append(generateComponent(comp.compPanel as List<T>, comp.name))
   * }
   * }
   * return members;
   * 
   * }
   */
  public <T extends Object> CharSequence injectCode(final T comp, final String prede) {
    boolean _matched = false;
    if (comp instanceof LABEL) {
      _matched=true;
      StringConcatenation _builder = new StringConcatenation();
      String _name = JLabel.class.getName();
      _builder.append(_name);
      _builder.append(" ");
      String _name_1 = ((LABEL)comp).getName();
      _builder.append(_name_1);
      _builder.append(" = new ");
      String _name_2 = JLabel.class.getName();
      _builder.append(_name_2);
      _builder.append("(\"");
      String _contenido = ((LABEL)comp).getContenido();
      _builder.append(_contenido);
      _builder.append("\");");
      _builder.newLineIfNotEmpty();
      _builder.append(prede);
      _builder.append(".add(");
      String _name_3 = ((LABEL)comp).getName();
      _builder.append(_name_3);
      _builder.append(");");
      _builder.newLineIfNotEmpty();
      _builder.newLine();
      return _builder;
    }
    if (!_matched) {
      if (comp instanceof PANEL) {
        _matched=true;
        StringConcatenation _builder = new StringConcatenation();
        String _name = JPanel.class.getName();
        _builder.append(_name);
        _builder.append(" ");
        String _name_1 = ((PANEL)comp).getName();
        _builder.append(_name_1);
        _builder.append(" = new ");
        String _name_2 = JPanel.class.getName();
        _builder.append(_name_2);
        _builder.append("();");
        _builder.newLineIfNotEmpty();
        String _name_3 = ((PANEL)comp).getName();
        _builder.append(_name_3);
        _builder.append(".setBackground(");
        String _name_4 = Color.class.getName();
        _builder.append(_name_4);
        _builder.append(".");
        String _color = ((PANEL)comp).getColor().getColor();
        _builder.append(_color);
        _builder.append(");");
        _builder.newLineIfNotEmpty();
        {
          BOOLEAN _tabbed = ((PANEL)comp).getTabbed();
          boolean _tripleEquals = (_tabbed == null);
          if (_tripleEquals) {
            _builder.append(prede);
            _builder.append(".add(");
            String _name_5 = ((PANEL)comp).getName();
            _builder.append(_name_5);
            _builder.append(");");
            _builder.newLineIfNotEmpty();
          }
        }
        String _name_6 = ((PANEL)comp).getName();
        _builder.append(_name_6);
        _builder.append(".setLayout(new ");
        String _name_7 = GridLayout.class.getName();
        _builder.append(_name_7);
        _builder.append("(1, 1));\t");
        _builder.newLineIfNotEmpty();
        _builder.append("\t\t\t\t\t\t\t\t\t");
        _builder.newLine();
        return _builder;
      }
    }
    if (!_matched) {
      if (comp instanceof BUTTON) {
        _matched=true;
        StringConcatenation _builder = new StringConcatenation();
        String _name = JButton.class.getName();
        _builder.append(_name);
        _builder.append(" ");
        String _name_1 = ((BUTTON)comp).getName();
        _builder.append(_name_1);
        _builder.append(" = new ");
        String _name_2 = JButton.class.getName();
        _builder.append(_name_2);
        _builder.append("(\"");
        String _contenido = ((BUTTON)comp).getContenido();
        _builder.append(_contenido);
        _builder.append("\");");
        _builder.newLineIfNotEmpty();
        _builder.append(prede);
        _builder.append(".add(");
        String _name_3 = ((BUTTON)comp).getName();
        _builder.append(_name_3);
        _builder.append(");");
        _builder.newLineIfNotEmpty();
        _builder.newLine();
        return _builder;
      }
    }
    if (!_matched) {
      if (comp instanceof RADIOBUTTON) {
        _matched=true;
        StringConcatenation _builder = new StringConcatenation();
        String _name = JRadioButton.class.getName();
        _builder.append(_name);
        _builder.append(" ");
        String _name_1 = ((RADIOBUTTON)comp).getName();
        _builder.append(_name_1);
        _builder.append(" = new ");
        String _name_2 = JRadioButton.class.getName();
        _builder.append(_name_2);
        _builder.append("(\"");
        String _contenido = ((RADIOBUTTON)comp).getContenido();
        _builder.append(_contenido);
        _builder.append("\");");
        _builder.newLineIfNotEmpty();
        String _name_3 = ((RADIOBUTTON)comp).getName();
        _builder.append(_name_3);
        _builder.append(".setSelected(");
        String _state = ((RADIOBUTTON)comp).getSelect().getState();
        _builder.append(_state);
        _builder.append(");");
        _builder.newLineIfNotEmpty();
        _builder.append(prede);
        _builder.append(".add(");
        String _name_4 = ((RADIOBUTTON)comp).getName();
        _builder.append(_name_4);
        _builder.append(");");
        _builder.newLineIfNotEmpty();
        _builder.newLine();
        return _builder;
      }
    }
    if (!_matched) {
      if (comp instanceof BUTTONGROUP) {
        _matched=true;
        StringConcatenation _builder = new StringConcatenation();
        String _name = ButtonGroup.class.getName();
        _builder.append(_name);
        _builder.append(" ");
        String _name_1 = ((BUTTONGROUP)comp).getName();
        _builder.append(_name_1);
        _builder.append(" = new ");
        String _name_2 = ButtonGroup.class.getName();
        _builder.append(_name_2);
        _builder.append("();");
        _builder.newLineIfNotEmpty();
        {
          EList<RADIOBUTTON> _compGroup = ((BUTTONGROUP)comp).getCompGroup();
          for(final RADIOBUTTON k : _compGroup) {
            String _name_3 = ((BUTTONGROUP)comp).getName();
            _builder.append(_name_3);
            _builder.append(".add(");
            String _name_4 = k.getName();
            _builder.append(_name_4);
            _builder.append(");");
            _builder.newLineIfNotEmpty();
          }
        }
        _builder.newLine();
        return _builder;
      }
    }
    if (!_matched) {
      if (comp instanceof TEXTFIELD) {
        _matched=true;
        StringConcatenation _builder = new StringConcatenation();
        String _name = JTextField.class.getName();
        _builder.append(_name);
        _builder.append(" ");
        String _name_1 = ((TEXTFIELD)comp).getName();
        _builder.append(_name_1);
        _builder.append(" = new ");
        String _name_2 = JTextField.class.getName();
        _builder.append(_name_2);
        _builder.append("(\"");
        String _contenido = ((TEXTFIELD)comp).getContenido();
        _builder.append(_contenido);
        _builder.append("\");");
        _builder.newLineIfNotEmpty();
        _builder.append(prede);
        _builder.append(".add(");
        String _name_3 = ((TEXTFIELD)comp).getName();
        _builder.append(_name_3);
        _builder.append(");");
        _builder.newLineIfNotEmpty();
        _builder.newLine();
        return _builder;
      }
    }
    if (!_matched) {
      if (comp instanceof CHECKBOX) {
        _matched=true;
        StringConcatenation _builder = new StringConcatenation();
        String _name = JCheckBox.class.getName();
        _builder.append(_name);
        _builder.append(" ");
        String _name_1 = ((CHECKBOX)comp).getName();
        _builder.append(_name_1);
        _builder.append(" = new ");
        String _name_2 = JCheckBox.class.getName();
        _builder.append(_name_2);
        _builder.append("(\"");
        String _contenido = ((CHECKBOX)comp).getContenido();
        _builder.append(_contenido);
        _builder.append("\");");
        _builder.newLineIfNotEmpty();
        String _name_3 = ((CHECKBOX)comp).getName();
        _builder.append(_name_3);
        _builder.append(".setSelected(");
        String _state = ((CHECKBOX)comp).getSelect().getState();
        _builder.append(_state);
        _builder.append(");");
        _builder.newLineIfNotEmpty();
        _builder.append(prede);
        _builder.append(".add(");
        String _name_4 = ((CHECKBOX)comp).getName();
        _builder.append(_name_4);
        _builder.append(");");
        _builder.newLineIfNotEmpty();
        _builder.newLine();
        return _builder;
      }
    }
    if (!_matched) {
      if (comp instanceof COMBOBOX) {
        _matched=true;
        StringConcatenation _builder = new StringConcatenation();
        String _name = JComboBox.class.getName();
        _builder.append(_name);
        _builder.append(" ");
        String _name_1 = ((COMBOBOX)comp).getName();
        _builder.append(_name_1);
        _builder.append(" = new ");
        String _name_2 = JComboBox.class.getName();
        _builder.append(_name_2);
        _builder.append("();");
        _builder.newLineIfNotEmpty();
        {
          EList<String> _compCombo = ((COMBOBOX)comp).getCompCombo();
          for(final String k : _compCombo) {
            String _name_3 = ((COMBOBOX)comp).getName();
            _builder.append(_name_3);
            _builder.append(".addItem(\"");
            _builder.append(k);
            _builder.append("\");");
            _builder.newLineIfNotEmpty();
          }
        }
        _builder.append(prede);
        _builder.append(".add(");
        String _name_4 = ((COMBOBOX)comp).getName();
        _builder.append(_name_4);
        _builder.append(");");
        _builder.newLineIfNotEmpty();
        _builder.newLine();
        return _builder;
      }
    }
    if (!_matched) {
      if (comp instanceof TABBEDPANE) {
        _matched=true;
        StringConcatenation _builder = new StringConcatenation();
        String _name = JTabbedPane.class.getName();
        _builder.append(_name);
        _builder.append(" ");
        String _name_1 = ((TABBEDPANE)comp).getName();
        _builder.append(_name_1);
        _builder.append(" = new ");
        String _name_2 = JTabbedPane.class.getName();
        _builder.append(_name_2);
        _builder.append("();");
        _builder.newLineIfNotEmpty();
        {
          EList<PANEL> _compTabbed = ((TABBEDPANE)comp).getCompTabbed();
          for(final PANEL k : _compTabbed) {
            String _name_3 = ((TABBEDPANE)comp).getName();
            _builder.append(_name_3);
            _builder.append(".addTab(\"");
            String _tab = k.getTab();
            _builder.append(_tab);
            _builder.append("\", ");
            String _name_4 = k.getName();
            _builder.append(_name_4);
            _builder.append(");");
            _builder.newLineIfNotEmpty();
          }
        }
        _builder.append(prede);
        _builder.append(".add(");
        String _name_5 = ((TABBEDPANE)comp).getName();
        _builder.append(_name_5);
        _builder.append(");");
        _builder.newLineIfNotEmpty();
        _builder.newLine();
        return _builder;
      }
    }
    return null;
  }
}
